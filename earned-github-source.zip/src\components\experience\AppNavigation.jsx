export default function AppNavigation({items,activeView,unreadCount=0,onNavigate}){
  return(
    <nav className="earned-app-nav" aria-label="Earned sections">
      <div className="earned-app-nav__track">
        {items.map(item=>{
          const active=activeView===item.id;
          const primary=item.id==="log";
          return(
            <button key={item.id} type="button" aria-current={active?"page":undefined}
              data-view-transition={active?"active":item.id}
              className={`earned-app-nav__item${primary?" earned-app-nav__item--train":""}`}
              onClick={()=>onNavigate?.(item.id)}>
              {primary&&<span className="earned-app-nav__plus" aria-hidden="true">+</span>}
              <span>{item.label}</span>
              {item.id==="community"&&unreadCount>0&&(
                <span className="earned-app-nav__badge" aria-label={`${unreadCount} unread notifications`}>
                  {Math.min(unreadCount,9)}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
